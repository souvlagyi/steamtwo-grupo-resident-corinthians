from pathlib import Path

from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER, TA_LEFT
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import cm
from reportlab.platypus import (
    HRFlowable,
    Image,
    KeepTogether,
    PageBreak,
    Paragraph,
    Spacer,
    Table,
    TableStyle,
)
from reportlab.platypus.doctemplate import SimpleDocTemplate


ROOT = Path(__file__).resolve().parent
DOCS = ROOT / "docs"
EVIDENCE = DOCS / "evidencias"
OUTPUT = DOCS / "Relatorio_SteamTwo_Grupo_Resident_Corinthians.pdf"

BLUE = colors.HexColor("#0877FF")
NAVY = colors.HexColor("#0D1723")
INK = colors.HexColor("#17212B")
MUTED = colors.HexColor("#52616D")
LINE = colors.HexColor("#C8D3DE")
LIGHT = colors.HexColor("#F3F7FA")
GREEN = colors.HexColor("#167A45")
AMBER = colors.HexColor("#8E5A16")


styles = getSampleStyleSheet()
styles.add(ParagraphStyle(
    name="CoverTitle", parent=styles["Title"], fontName="Helvetica-Bold",
    fontSize=30, leading=35, textColor=colors.white, alignment=TA_CENTER, spaceAfter=14,
))
styles.add(ParagraphStyle(
    name="CoverSubtitle", parent=styles["BodyText"], fontName="Helvetica",
    fontSize=13, leading=19, textColor=colors.HexColor("#DCEBFA"), alignment=TA_CENTER,
))
styles.add(ParagraphStyle(
    name="CoverRepo", parent=styles["BodyText"], fontName="Helvetica",
    fontSize=10.5, leading=14, textColor=colors.HexColor("#DCEBFA"), alignment=TA_CENTER,
))
styles.add(ParagraphStyle(
    name="H1Custom", parent=styles["Heading1"], fontName="Helvetica-Bold",
    fontSize=21, leading=26, textColor=NAVY, spaceAfter=11, spaceBefore=2,
))
styles.add(ParagraphStyle(
    name="H2Custom", parent=styles["Heading2"], fontName="Helvetica-Bold",
    fontSize=13, leading=17, textColor=BLUE, spaceAfter=7, spaceBefore=9,
))
styles.add(ParagraphStyle(
    name="BodyCustom", parent=styles["BodyText"], fontName="Helvetica",
    fontSize=9.5, leading=14, textColor=INK, spaceAfter=7,
))
styles.add(ParagraphStyle(
    name="SmallCustom", parent=styles["BodyText"], fontName="Helvetica",
    fontSize=8, leading=11, textColor=MUTED,
))
styles.add(ParagraphStyle(
    name="TableHeader", parent=styles["BodyText"], fontName="Helvetica-Bold",
    fontSize=8, leading=11, textColor=colors.white,
))
styles.add(ParagraphStyle(
    name="CoverFooter", parent=styles["BodyText"], fontName="Helvetica",
    fontSize=13, leading=18, textColor=NAVY, alignment=TA_CENTER,
))
styles.add(ParagraphStyle(
    name="Caption", parent=styles["BodyText"], fontName="Helvetica-Oblique",
    fontSize=8.5, leading=11, textColor=MUTED, alignment=TA_CENTER, spaceAfter=9,
))
styles.add(ParagraphStyle(
    name="Callout", parent=styles["BodyText"], fontName="Helvetica-Bold",
    fontSize=9.5, leading=14, textColor=AMBER,
))


def p(text, style="BodyCustom"):
    return Paragraph(text, styles[style])


def footer(canvas, doc):
    canvas.saveState()
    canvas.setStrokeColor(LINE)
    canvas.line(1.8 * cm, 1.25 * cm, A4[0] - 1.8 * cm, 1.25 * cm)
    canvas.setFont("Helvetica", 8)
    canvas.setFillColor(MUTED)
    canvas.drawString(1.8 * cm, 0.82 * cm, "SteamTwo - relatório acadêmico do grupo")
    canvas.drawRightString(A4[0] - 1.8 * cm, 0.82 * cm, f"Página {doc.page}")
    canvas.restoreState()


def info_table(rows, widths=(4.0 * cm, 12.4 * cm)):
    table = Table([[p(a, "SmallCustom"), p(b)] for a, b in rows], colWidths=widths, hAlign="LEFT")
    table.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (0, -1), colors.HexColor("#E9F2FB")),
        ("GRID", (0, 0), (-1, -1), 0.35, LINE),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ("LEFTPADDING", (0, 0), (-1, -1), 8),
        ("RIGHTPADDING", (0, 0), (-1, -1), 8),
        ("TOPPADDING", (0, 0), (-1, -1), 7),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 7),
    ]))
    return table


def data_table(headers, rows, widths):
    table = Table([[p(header, "TableHeader") for header in headers] + []] + [[p(cell) for cell in row] for row in rows], colWidths=widths, repeatRows=1, hAlign="LEFT")
    table.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), NAVY),
        ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
        ("GRID", (0, 0), (-1, -1), 0.35, LINE),
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, LIGHT]),
        ("LEFTPADDING", (0, 0), (-1, -1), 7),
        ("RIGHTPADDING", (0, 0), (-1, -1), 7),
        ("TOPPADDING", (0, 0), (-1, -1), 7),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 7),
    ]))
    return table


def evidence_image(filename, caption, width=16.5 * cm):
    image = Image(str(EVIDENCE / filename), width=width, height=width * 0.5625)
    return [image, p(caption, "Caption")]


document = SimpleDocTemplate(
    str(OUTPUT), pagesize=A4, leftMargin=1.8 * cm, rightMargin=1.8 * cm,
    topMargin=1.6 * cm, bottomMargin=1.7 * cm,
)

story = []

# Cover
cover = Table([[""], [""], [""], [""], [""], [""], [""], [""]], colWidths=[17.4 * cm], rowHeights=[1.0 * cm, 1.2 * cm, 2.6 * cm, 1.5 * cm, 1.2 * cm, 2.0 * cm, 1.6 * cm, 1.0 * cm])
cover.setStyle(TableStyle([("BACKGROUND", (0, 0), (-1, -1), NAVY)]))
story.append(cover)
story.append(Spacer(1, -11.1 * cm))
story.append(p("RELATÓRIO ACADÊMICO", "CoverSubtitle"))
story.append(Spacer(1, 0.65 * cm))
story.append(p("Evolução do SteamTwo", "CoverTitle"))
story.append(p("Biblioteca pessoal, comparador de jogos e integração preparada para PostgreSQL", "CoverSubtitle"))
story.append(Spacer(1, 1.45 * cm))
cover_info = Table([
    [p("GRUPO", "TableHeader"), p("Grupo Resident Corinthians", "CoverSubtitle")],
    [p("INTEGRANTES", "TableHeader"), p("Guilherme Nomoto Matuhashi<br/>José Octávio Zansavio Pereira", "CoverSubtitle")],
    [p("REPOSITÓRIO", "TableHeader"), p("https://github.com/<br/>souvlagyi/steamtwo-grupo-resident-corinthians", "CoverRepo")],
], colWidths=[3.5 * cm, 13.9 * cm])
cover_info.setStyle(TableStyle([
    ("BACKGROUND", (0, 0), (-1, -1), colors.HexColor("#142A40")),
    ("BOX", (0, 0), (-1, -1), 0.5, colors.HexColor("#49759D")),
    ("INNERGRID", (0, 0), (-1, -1), 0.35, colors.HexColor("#49759D")),
    ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
    ("LEFTPADDING", (0, 0), (-1, -1), 10),
    ("RIGHTPADDING", (0, 0), (-1, -1), 10),
    ("TOPPADDING", (0, 0), (-1, -1), 10),
    ("BOTTOMPADDING", (0, 0), (-1, -1), 10),
]))
story.append(cover_info)
story.append(Spacer(1, 2.0 * cm))
story.append(p("FATEC - Análise e Desenvolvimento de Sistemas - 2026", "CoverFooter"))
story.append(PageBreak())

# Objective
story.append(p("1. O que foi entregue", "H1Custom"))
story.append(p("Esta versão do SteamTwo parte do projeto-base indicado na atividade e amplia a experiência do catálogo com recursos autorais orientados à decisão do usuário: uma biblioteca pessoal com progresso e notas, um comparador de dois ou três jogos e uma rotina de dados locais para demonstrar a integração com PostgreSQL."))
story.append(info_table([
    ("Projeto-base", "https://github.com/DavidSilvaProg/steamtwo"),
    ("Novo repositório", "https://github.com/souvlagyi/steamtwo-grupo-resident-corinthians"),
    ("Tecnologias", "React + Vite no front-end; Node.js + Express na API; PostgreSQL e biblioteca pg na persistência."),
    ("Segurança", "O repositório possui somente .env.example. O arquivo .env com a URL do banco e eventuais chaves não deve ser publicado."),
]))
story.append(Spacer(1, 0.35 * cm))
story.append(p("Como a entrega atende à atividade", "H2Custom"))
story.append(data_table(["Critério", "Entrega do grupo", "Evidência"], [
    ("Back-end e PostgreSQL", "Migrações de domínio e da biblioteca; repositórios SQL separados; seed local.", "Migrations 001 e 002; rotas /api/library; comando db:seed."),
    ("Melhorias relevantes", "Biblioteca com status/nota e comparador de jogos com resumo de diferença e gêneros comuns.", "Interface, endpoints e testes específicos."),
    ("Integração e qualidade", "React consome API Express; serviços isolam regra; validações Zod; foco visível e estado ARIA.", "26 testes automatizados e build validado."),
    ("Documentação", "README, instruções, registro de testes e este PDF com capturas.", "Pasta docs/ no novo repositório."),
], [3.0 * cm, 8.2 * cm, 6.2 * cm]))
story.append(PageBreak())

# improvements
story.append(p("2. Melhorias autorais", "H1Custom"))
story.append(data_table(["Melhoria", "Como funciona", "Benefício para o usuário"], [
    ("Minha biblioteca", "Salva o jogo no perfil local com os status Quero jogar, Jogando ou Concluído e uma nota de até 280 caracteres.", "Organiza a próxima experiência de jogo e mantém o contexto do usuário."),
    ("Comparador", "Permite escolher até três títulos e comparar índice, popularidade histórica, tendência, lojas e gêneros.", "Ajuda a decidir entre jogos sem alternar entre várias telas."),
    ("Seed do banco", "Insere catálogo e rankings de demonstração após as migrações, sem exigir credenciais externas.", "Permite comprovar interface, API e banco localmente."),
    ("Validação e acessibilidade", "Zod valida slugs, status e quantidade de itens; botões de comparação expõem aria-pressed e foco visível.", "Evita requisições inválidas e torna o fluxo mais claro para teclado/leitor de tela."),
], [3.2 * cm, 7.6 * cm, 6.6 * cm]))
story.append(Spacer(1, 0.5 * cm))
story.append(p("Endpoints acrescentados", "H2Custom"))
story.append(data_table(["Método", "Endpoint", "Resposta esperada"], [
    ("GET", "/api/compare?slugs=jogo-a,jogo-b", "Dois ou três jogos e um resumo com diferença de índice e gêneros compartilhados."),
    ("GET", "/api/library", "Itens salvos com status, nota e dados do jogo."),
    ("PUT", "/api/library/:slug", "Inclui ou atualiza status e nota do jogo selecionado."),
    ("DELETE", "/api/library/:slug", "Remove o jogo da biblioteca do perfil local."),
], [2.1 * cm, 6.1 * cm, 9.2 * cm]))
story.append(Spacer(1, 0.55 * cm))
story.append(p("A implementação evita replicar os campos do catálogo na biblioteca: a tabela game_library guarda apenas a referência ao jogo, estado e nota. Ao listar a biblioteca, o repositório SQL monta uma visão com gêneros, lojas e indicadores do catálogo."))
story.append(PageBreak())

# integration
story.append(p("3. Integração com PostgreSQL", "H1Custom"))
story.append(p("A interface React envia requisições HTTP para a API Express. As rotas validam entradas com Zod e chamam serviços de catálogo ou biblioteca. Com DATABASE_URL configurada, esses serviços usam repositórios SQL baseados em pg e consultas parametrizadas. A biblioteca é persistida em game_library, ligada ao catálogo pela chave game_id."))
flow = Table([[p("Interface React\nCatálogo, biblioteca e comparação", "SmallCustom"), p("API Express\nRotas e validação", "SmallCustom"), p("Serviços\nRegras de domínio", "SmallCustom"), p("Repositórios SQL\npg + parâmetros", "SmallCustom"), p("PostgreSQL\nTabelas migradas", "SmallCustom")]], colWidths=[3.35 * cm] * 5)
flow.setStyle(TableStyle([
    ("BACKGROUND", (0, 0), (-1, -1), colors.HexColor("#E9F2FB")),
    ("BOX", (0, 0), (-1, -1), 0.6, BLUE),
    ("INNERGRID", (0, 0), (-1, -1), 0.45, BLUE),
    ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
    ("ALIGN", (0, 0), (-1, -1), "CENTER"),
    ("TOPPADDING", (0, 0), (-1, -1), 16),
    ("BOTTOMPADDING", (0, 0), (-1, -1), 16),
]))
story.append(Spacer(1, 0.2 * cm)); story.append(flow)
story.append(p("Migrações e dados de demonstração", "H2Custom"))
story.append(data_table(["Arquivo/comando", "Papel"], [
    ("001_create_steamtwo_domain", "Cria jogos, gêneros, lojas, snapshots e rankings."),
    ("002_create_game_library", "Cria game_library com status, nota limitada a 280 caracteres e chave estrangeira para games."),
    ("npm run db:migrate", "Aplica o esquema na instância PostgreSQL configurada."),
    ("npm run db:seed", "Inclui jogos e rankings de demonstração para que as telas funcionem com dados do banco."),
    ("GET /api/health", "Executa SELECT 1 quando DATABASE_URL está configurada e retorna database.status: connected."),
], [5.1 * cm, 12.3 * cm]))
story.append(Spacer(1, 0.3 * cm))
note = Table([[p("Antes da submissão, execute db:migrate e db:seed usando o DATABASE_URL do grupo e inclua no PDF a captura de /api/health com database.status igual a connected. A máquina usada para preparar este modelo possuía o serviço PostgreSQL, mas não tinha a senha da instância disponibilizada.", "Callout")]], colWidths=[17.4 * cm])
note.setStyle(TableStyle([("BACKGROUND", (0, 0), (-1, -1), colors.HexColor("#FFF7E8")), ("BOX", (0, 0), (-1, -1), 0.45, colors.HexColor("#E7B461")), ("LEFTPADDING", (0, 0), (-1, -1), 10), ("RIGHTPADDING", (0, 0), (-1, -1), 10), ("TOPPADDING", (0, 0), (-1, -1), 9), ("BOTTOMPADDING", (0, 0), (-1, -1), 9)]))
story.append(note)
story.append(PageBreak())

# Evidence dashboard
story.append(p("4. Evidências de funcionamento", "H1Custom"))
story.append(p("As capturas abaixo foram registradas localmente após iniciar a API. Elas demonstram a navegação e as funcionalidades do grupo em modo de demonstração. Com o banco do grupo configurado e populado, as mesmas telas passam a receber os dados pelos repositórios PostgreSQL."))
story.extend(evidence_image("01-dashboard.png", "Figura 1 - Dashboard consumindo a API do SteamTwo e exibindo o destaque, ranking e indicadores."))
story.append(p("Na figura 1, Elden Ring foi adicionado à biblioteca e dois jogos já estão selecionados para comparação. O indicador no cabeçalho acompanha a seleção do usuário."))
story.append(PageBreak())

# evidence library comparison
story.append(p("5. Biblioteca e comparação", "H1Custom"))
story.extend(evidence_image("02-biblioteca.png", "Figura 2 - Tela Minha biblioteca com Elden Ring, status Jogando e nota registrada."))
story.append(Spacer(1, 0.2 * cm))
story.extend(evidence_image("03-comparador.png", "Figura 3 - Comparação entre Elden Ring e Black Myth: Wukong, incluindo diferença de índice e gêneros em comum."))
story.append(PageBreak())

# tests and how run
story.append(p("6. Testes, execução e checklist", "H1Custom"))
story.append(data_table(["Verificação", "Resultado observado"], [
    ("Testes de domínio, API e integrações", "26 testes aprovados em 6 arquivos. Incluem comparação, salvar/atualizar/remover biblioteca e validações."),
    ("Build de produção", "Concluído com 4.570 módulos transformados."),
    ("Teste de preparação para Sites", "4 de 4 testes aprovados."),
    ("Teste PostgreSQL da entrega", "Pendente da credencial da instância do grupo: aplicar migrações, rodar seed e capturar /api/health conectado."),
], [6.0 * cm, 11.4 * cm]))
story.append(p("Como executar", "H2Custom"))
steps = [
    "1. Clone o novo repositório do grupo e entre na pasta.",
    "2. Instale dependências: npm install.",
    "3. Crie .env a partir de .env.example e informe o DATABASE_URL local do grupo.",
    "4. Inicie PostgreSQL (docker compose up -d, se usar Docker).",
    "5. Rode npm run db:migrate e npm run db:seed.",
    "6. Em dois terminais, rode npm run dev:api e npm run dev.",
    "7. Abra a interface em http://127.0.0.1:5173/ e a saúde da API em http://127.0.0.1:3001/api/health.",
]
for step in steps:
    story.append(p(step))
story.append(p("Checklist antes de enviar", "H2Custom"))
checklist = Table([[p("□", "H2Custom"), p("Confirmar o link do repositório na capa após a publicação no GitHub." )], [p("□", "H2Custom"), p("Executar a integração PostgreSQL do grupo e inserir a captura de /api/health conectado." )], [p("□", "H2Custom"), p("Confirmar npm test, npm run build e npm run test:sites na versão final." )], [p("□", "H2Custom"), p("Garantir que .env, senhas e chaves não foram enviados ao GitHub." )]], colWidths=[0.7 * cm, 16.7 * cm])
checklist.setStyle(TableStyle([("VALIGN", (0, 0), (-1, -1), "TOP"), ("LINEBELOW", (0, 0), (-1, -1), 0.3, LINE), ("TOPPADDING", (0, 0), (-1, -1), 5), ("BOTTOMPADDING", (0, 0), (-1, -1), 5)]))
story.append(checklist)

document.build(story, onFirstPage=footer, onLaterPages=footer)
print(OUTPUT)
